#include <systemc>
#include <vector>
#include <iostream>
#include "hls_stream.h"
#include "ap_int.h"
#include "ap_fixed.h"
using namespace std;
using namespace sc_dt;
class AESL_RUNTIME_BC {
  public:
    AESL_RUNTIME_BC(const char* name) {
      file_token.open( name);
      if (!file_token.good()) {
        cout << "Failed to open tv file " << name << endl;
        exit (1);
      }
      file_token >> mName;//[[[runtime]]]
    }
    ~AESL_RUNTIME_BC() {
      file_token.close();
    }
    int read_size () {
      int size = 0;
      file_token >> mName;//[[transaction]]
      file_token >> mName;//transaction number
      file_token >> mName;//pop_size
      size = atoi(mName.c_str());
      file_token >> mName;//[[/transaction]]
      return size;
    }
  public:
    fstream file_token;
    string mName;
};
extern "C" void addweighted(int*, int*, int*, int, int, int, int, int);
extern "C" void apatb_addweighted_hw(volatile void * __xlx_apatb_param_img_inp_one, volatile void * __xlx_apatb_param_img_inp_two, volatile void * __xlx_apatb_param_img_out, int __xlx_apatb_param_height, int __xlx_apatb_param_width) {
  // Collect __xlx_img_inp_one__tmp_vec
  vector<sc_bv<32> >__xlx_img_inp_one__tmp_vec;
  for (int j = 0, e = 1; j != e; ++j) {
    __xlx_img_inp_one__tmp_vec.push_back(((int*)__xlx_apatb_param_img_inp_one)[j]);
  }
  int __xlx_size_param_img_inp_one = 1;
  int __xlx_offset_param_img_inp_one = 0;
  int __xlx_offset_byte_param_img_inp_one = 0*4;
  int* __xlx_img_inp_one__input_buffer= new int[__xlx_img_inp_one__tmp_vec.size()];
  for (int i = 0; i < __xlx_img_inp_one__tmp_vec.size(); ++i) {
    __xlx_img_inp_one__input_buffer[i] = __xlx_img_inp_one__tmp_vec[i].range(31, 0).to_uint64();
  }
  // Collect __xlx_img_inp_two__tmp_vec
  vector<sc_bv<32> >__xlx_img_inp_two__tmp_vec;
  for (int j = 0, e = 1; j != e; ++j) {
    __xlx_img_inp_two__tmp_vec.push_back(((int*)__xlx_apatb_param_img_inp_two)[j]);
  }
  int __xlx_size_param_img_inp_two = 1;
  int __xlx_offset_param_img_inp_two = 0;
  int __xlx_offset_byte_param_img_inp_two = 0*4;
  int* __xlx_img_inp_two__input_buffer= new int[__xlx_img_inp_two__tmp_vec.size()];
  for (int i = 0; i < __xlx_img_inp_two__tmp_vec.size(); ++i) {
    __xlx_img_inp_two__input_buffer[i] = __xlx_img_inp_two__tmp_vec[i].range(31, 0).to_uint64();
  }
  // Collect __xlx_img_out__tmp_vec
  vector<sc_bv<32> >__xlx_img_out__tmp_vec;
  for (int j = 0, e = 1; j != e; ++j) {
    __xlx_img_out__tmp_vec.push_back(((int*)__xlx_apatb_param_img_out)[j]);
  }
  int __xlx_size_param_img_out = 1;
  int __xlx_offset_param_img_out = 0;
  int __xlx_offset_byte_param_img_out = 0*4;
  int* __xlx_img_out__input_buffer= new int[__xlx_img_out__tmp_vec.size()];
  for (int i = 0; i < __xlx_img_out__tmp_vec.size(); ++i) {
    __xlx_img_out__input_buffer[i] = __xlx_img_out__tmp_vec[i].range(31, 0).to_uint64();
  }
  // DUT call
  addweighted(__xlx_img_inp_one__input_buffer, __xlx_img_inp_two__input_buffer, __xlx_img_out__input_buffer, __xlx_offset_byte_param_img_inp_one, __xlx_offset_byte_param_img_inp_two, __xlx_offset_byte_param_img_out, __xlx_apatb_param_height, __xlx_apatb_param_width);
// print __xlx_apatb_param_img_inp_one
  sc_bv<32>*__xlx_img_inp_one_output_buffer = new sc_bv<32>[__xlx_size_param_img_inp_one];
  for (int i = 0; i < __xlx_size_param_img_inp_one; ++i) {
    __xlx_img_inp_one_output_buffer[i] = __xlx_img_inp_one__input_buffer[i+__xlx_offset_param_img_inp_one];
  }
  for (int i = 0; i < __xlx_size_param_img_inp_one; ++i) {
    ((int*)__xlx_apatb_param_img_inp_one)[i] = __xlx_img_inp_one_output_buffer[i].to_uint64();
  }
// print __xlx_apatb_param_img_inp_two
  sc_bv<32>*__xlx_img_inp_two_output_buffer = new sc_bv<32>[__xlx_size_param_img_inp_two];
  for (int i = 0; i < __xlx_size_param_img_inp_two; ++i) {
    __xlx_img_inp_two_output_buffer[i] = __xlx_img_inp_two__input_buffer[i+__xlx_offset_param_img_inp_two];
  }
  for (int i = 0; i < __xlx_size_param_img_inp_two; ++i) {
    ((int*)__xlx_apatb_param_img_inp_two)[i] = __xlx_img_inp_two_output_buffer[i].to_uint64();
  }
// print __xlx_apatb_param_img_out
  sc_bv<32>*__xlx_img_out_output_buffer = new sc_bv<32>[__xlx_size_param_img_out];
  for (int i = 0; i < __xlx_size_param_img_out; ++i) {
    __xlx_img_out_output_buffer[i] = __xlx_img_out__input_buffer[i+__xlx_offset_param_img_out];
  }
  for (int i = 0; i < __xlx_size_param_img_out; ++i) {
    ((int*)__xlx_apatb_param_img_out)[i] = __xlx_img_out_output_buffer[i].to_uint64();
  }
}
