// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xaddweighted.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAddweighted_CfgInitialize(XAddweighted *InstancePtr, XAddweighted_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAddweighted_Start(XAddweighted *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_AP_CTRL) & 0x80;
    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XAddweighted_IsDone(XAddweighted *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XAddweighted_IsIdle(XAddweighted *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XAddweighted_IsReady(XAddweighted *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XAddweighted_EnableAutoRestart(XAddweighted *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XAddweighted_DisableAutoRestart(XAddweighted *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_AP_CTRL, 0);
}

void XAddweighted_Set_img_inp_one(XAddweighted *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IMG_INP_ONE_DATA, (u32)(Data));
    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IMG_INP_ONE_DATA + 4, (u32)(Data >> 32));
}

u64 XAddweighted_Get_img_inp_one(XAddweighted *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IMG_INP_ONE_DATA);
    Data += (u64)XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IMG_INP_ONE_DATA + 4) << 32;
    return Data;
}

void XAddweighted_Set_img_inp_two(XAddweighted *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IMG_INP_TWO_DATA, (u32)(Data));
    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IMG_INP_TWO_DATA + 4, (u32)(Data >> 32));
}

u64 XAddweighted_Get_img_inp_two(XAddweighted *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IMG_INP_TWO_DATA);
    Data += (u64)XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IMG_INP_TWO_DATA + 4) << 32;
    return Data;
}

void XAddweighted_Set_img_out(XAddweighted *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IMG_OUT_DATA, (u32)(Data));
    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IMG_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XAddweighted_Get_img_out(XAddweighted *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IMG_OUT_DATA);
    Data += (u64)XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IMG_OUT_DATA + 4) << 32;
    return Data;
}

void XAddweighted_Set_height(XAddweighted *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_HEIGHT_DATA, Data);
}

u32 XAddweighted_Get_height(XAddweighted *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_HEIGHT_DATA);
    return Data;
}

void XAddweighted_Set_width(XAddweighted *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XAddweighted_Get_width(XAddweighted *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XAddweighted_InterruptGlobalEnable(XAddweighted *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_GIE, 1);
}

void XAddweighted_InterruptGlobalDisable(XAddweighted *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_GIE, 0);
}

void XAddweighted_InterruptEnable(XAddweighted *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IER);
    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IER, Register | Mask);
}

void XAddweighted_InterruptDisable(XAddweighted *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IER);
    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IER, Register & (~Mask));
}

void XAddweighted_InterruptClear(XAddweighted *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAddweighted_WriteReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_ISR, Mask);
}

u32 XAddweighted_InterruptGetEnabled(XAddweighted *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_IER);
}

u32 XAddweighted_InterruptGetStatus(XAddweighted *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAddweighted_ReadReg(InstancePtr->Control_BaseAddress, XADDWEIGHTED_CONTROL_ADDR_ISR);
}

