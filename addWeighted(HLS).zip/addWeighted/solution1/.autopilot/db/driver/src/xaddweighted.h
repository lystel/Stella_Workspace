// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XADDWEIGHTED_H
#define XADDWEIGHTED_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xaddweighted_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XAddweighted_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XAddweighted;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XAddweighted_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XAddweighted_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XAddweighted_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XAddweighted_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XAddweighted_Initialize(XAddweighted *InstancePtr, u16 DeviceId);
XAddweighted_Config* XAddweighted_LookupConfig(u16 DeviceId);
int XAddweighted_CfgInitialize(XAddweighted *InstancePtr, XAddweighted_Config *ConfigPtr);
#else
int XAddweighted_Initialize(XAddweighted *InstancePtr, const char* InstanceName);
int XAddweighted_Release(XAddweighted *InstancePtr);
#endif

void XAddweighted_Start(XAddweighted *InstancePtr);
u32 XAddweighted_IsDone(XAddweighted *InstancePtr);
u32 XAddweighted_IsIdle(XAddweighted *InstancePtr);
u32 XAddweighted_IsReady(XAddweighted *InstancePtr);
void XAddweighted_EnableAutoRestart(XAddweighted *InstancePtr);
void XAddweighted_DisableAutoRestart(XAddweighted *InstancePtr);

void XAddweighted_Set_img_inp_one(XAddweighted *InstancePtr, u64 Data);
u64 XAddweighted_Get_img_inp_one(XAddweighted *InstancePtr);
void XAddweighted_Set_img_inp_two(XAddweighted *InstancePtr, u64 Data);
u64 XAddweighted_Get_img_inp_two(XAddweighted *InstancePtr);
void XAddweighted_Set_img_out(XAddweighted *InstancePtr, u64 Data);
u64 XAddweighted_Get_img_out(XAddweighted *InstancePtr);
void XAddweighted_Set_height(XAddweighted *InstancePtr, u32 Data);
u32 XAddweighted_Get_height(XAddweighted *InstancePtr);
void XAddweighted_Set_width(XAddweighted *InstancePtr, u32 Data);
u32 XAddweighted_Get_width(XAddweighted *InstancePtr);

void XAddweighted_InterruptGlobalEnable(XAddweighted *InstancePtr);
void XAddweighted_InterruptGlobalDisable(XAddweighted *InstancePtr);
void XAddweighted_InterruptEnable(XAddweighted *InstancePtr, u32 Mask);
void XAddweighted_InterruptDisable(XAddweighted *InstancePtr, u32 Mask);
void XAddweighted_InterruptClear(XAddweighted *InstancePtr, u32 Mask);
u32 XAddweighted_InterruptGetEnabled(XAddweighted *InstancePtr);
u32 XAddweighted_InterruptGetStatus(XAddweighted *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
